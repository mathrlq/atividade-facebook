lugarDeBotarONome = document.getElementById("nomeDoSujeito");
lugarDeBotarONome.innerHTML = userData.name;

lugarDeBotarOlugar = document.getElementById("nomeDoLugar");
lugarDeBotarOlugar.innerHTML = userData.location;

lugarDeBotarOaniversario = document.getElementById("dataDoAniversario");
lugarDeBotarOaniversario.innerHTML = userData.birthday;

lugarDeBotarabio = document.getElementById("Bio");
lugarDeBotarabio.innerHTML = userData.bio;

lugarDeBotarOSexo = document.getElementById("Sexo");
lugarDeBotarOSexo.innerHTML = userData.sexo;

lugarDeBotarOSite = document.getElementById("Site");
lugarDeBotarOSite.innerHTML = userData.site;

lugarDeBotarAcor = document.getElementById("Cor");
lugarDeBotarAcor.innerHTML = userData.corfav;

lugarDeBotarFrase = document.getElementById("Frasefav");
lugarDeBotarFrase.innerHTML = userData.frasefav;

