const userData = {
    name: "markinhos",
    profilePicture: "https://example.com/profile.jpg",
    bio: "gosto de pular de costas",
    location: "Cancão",
    birthday: "01/01/4500 AC",
    site: "https://maçom.com/",
    joinDate: "Junho, 2015",
    sexo: "menininha",
    corfav: "Cor Favorita:roxo",
    frasefav: "tão feliz que as vezes dá vontade de morrer rindo!!!!!",
}
